<?php
// Heading
$_['heading_title']          = 'Litemf Api - не устанавливать!';
