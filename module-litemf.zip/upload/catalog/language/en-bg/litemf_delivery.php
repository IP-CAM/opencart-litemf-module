<?php
// Text
$_['text_title']       = 'Litemf';
$_['text_description'] = 'Доставка Litemf';

